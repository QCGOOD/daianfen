'use strict'

module.exports = {
  NODE_ENV: '"production"',
  // NODE_API: '"https://triumph.wego168.com"',
  // NODE_API: '"http://x.wego168.com/zhongrui"',
  // NODE_API: '"http://abs.wego168.com/accelerator"',
  // NODE_BASE: '"/triumph/employee"'
  // NODE_BASE: '"/zhongrui/mobile"'
}
