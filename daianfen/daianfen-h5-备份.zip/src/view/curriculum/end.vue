<template>
  <div class="end">
    <div class="box">
      <p class="title">选择您最认同的一句话作为课后感吧</p>
    </div>
  </div>
</template>

<style lang="less" scoped>
.box {
  position: fixed;
  top: 5vw;
  bottom: 5vw;
  left: 5vw;
  right: 5vw;
  background-color: #fff;
  overflow-y: auto;
  border: 1px solid #C7C7C7;
  .title {
    text-align: center;
    padding: 3vw 0;
    background-color: rgb(248, 248, 248);
  }
}
</style>
