 const other = [
 // 订单确认
    {
      path: '/order/confirm',
      component: resolve => require(['@/view/order/confirm'], resolve),
      meta: {
        title: '活动报名'
      }
    },
    {
      path: '/order/success',
      component: resolve => require(['@/view/order/success'], resolve),
      meta: {
        title: '活动报名'
      }
    },
    // 课程报名
    {
      path: '/order/lessonConfrim',
      component: resolve => require(['@/view/order/lessonConfrim'], resolve),
      meta: {
        title: '课程报名'
      }
    },
    // 课程报名成功
    {
      path: '/order/lessonSuccess',
      component: resolve => require(['@/view/order/lessonSuccess'], resolve)
    },
    // 试听券领取成功
    {
      path: '/order/couponSuccess',
      component: resolve => require(['@/view/order/couponSuccess'], resolve)
    },
    // 帮助
    {
      path: '/user/help',
      component: resolve => require(['@/components/User/help'], resolve)
    },
    // 历史
    {
      path: '/user/history',
      component: resolve => require(['@/components/User/history'], resolve)
    },
    // 适用活动
    {
      path: '/user/fitActivity',
      component: resolve => require(['@/view/user/fitActivity'], resolve),
      meta: {
        title: '适用活动'
      }
    },
    // 收藏
    {
      path: '/user/collect',
      component: resolve => require(['@/components/User/collect'], resolve)
    },

    // 排行
    {
      path: '/user/rank',
      component: resolve => require(['@/components/User/rank'], resolve)
    },
    // 领券
    {
      path: '/receiveSuccess',
      component: resolve => require(['@/components/receiveSuccess'], resolve)
    },
    // 适用活动
    {
      path: '/user/coupon/apply',
      component: resolve => require(['@/components/User/apply'], resolve)
    },
  ]
  export default other;